% *********************************************************
% Laborator PSS: Efectele cuantizarii prin rotunjire ale produselor si
% sumelor
% g1(): sumator in aritmetica C2, cu limita maxima la 1
%
% Inputs:
%   x = the value of the sum (infinite precision)
%
% *********************************************************

function y = g1(x)

  y = x - 2*fix((x+sign(x))/2);
  
##  y = x;
##  %
##  overflow_indices = (x >= 1);
##  y(overflow_indices) = -1 + (y(overflow_indices) - floor(y(overflow_indices)));
##  %
##  underflow_indices = (x < -1);
##  y(underflow_indices) = 1 + (y(underflow_indices) - ceil(y(underflow_indices)));

end
