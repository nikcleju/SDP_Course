function [K] = tf2latc_iir(a)
  
  # Exemplu:
  # a = [1   2/5    7/20    1/2]
  
  # Rezultat:
  # K = [0.25  0.2   0.5]
  
order = length(a) - 1;

K(order) = a(order+1);
b = fliplr(a);

for i=1:(order-1)

  # Define Km for easier handling
  Km = K(order+1-i);
  
  # Compute new A_m-1 and C_m-1 based on A_m, B_m and C_m
  a = (a - Km * b) / (1 - Km^2);
  
  # Read new coefficient K_{m-1}  = last coefficient of A_{m-1}(z)
  K(order+1-i-1) = a(order+1-i);
  
  # A_{m-1} is shorter with 1 coefficient than the previous A_m
  a = a(1:order+1-i)
  
  # Update b for new iteration
  # b = a in reverse order (flipped)
  b = fliplr(a);  
endfor

% Matlab: end
endfunction
