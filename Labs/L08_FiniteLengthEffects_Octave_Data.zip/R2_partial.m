% R2

clear all
close all

% Parametri
Wp = 
Ws = 
Rp =
Rs = 

% Esitmarea ordinului necesar
[n,Wp] = 

% Proiectarea filtrului
[b,a] = 

% Raspunsul filtrului in precizie infinita
[h0,w0] = freqz(b,a);

% Parametri necesari functiei qfr
K = numel(w0);
theta = [0 pi];

% In continuare se utilizeaza functia qfr pentru cuantizare

% 12 biti
B = 12;
H_12_dir = 
H_12_par = 
H_12_cas = 

% 6 biti
B = 6;
H_6_dir = 
H_6_par = 
H_6_cas = 

% Afisare pt 12 biti
figure(1);
plot(w0/pi,20*log10(abs(h0)),'b',w0/pi,20*log10(abs(H_12_dir)),'g',w0/pi,20*log10(abs(H_12_par)),'r', w0/pi,20*log10(abs(H_12_cas)),'m');
xlabel('\omega/\pi');ylabel('Castig  dB');
title('Cuantizare pe 12 biti');
legend('precizie infinita','directa','paralel','cascada');
axis([0 1 -80 20]);

% Afisare pt 6 biti
figure(2);
plot(w0/pi,20*log10(abs(h0)),'b',w0/pi,20*log10(abs(H_6_dir)),'g',w0/pi,20*log10(abs(H_6_par)),'r', w0/pi,20*log10(abs(H_6_cas)),'m');
xlabel('\omega/\pi');ylabel('Castig  dB');
title('Cuantizare pe 12 biti');
legend('precizie infinita','directa','paralel','cascada');
axis([0 1 -80 20]);
