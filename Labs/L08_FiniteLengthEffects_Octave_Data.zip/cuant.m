function aq=cuant(a,qtype,B)
%Cuantizeaza scalarul/vectorul a pe B biti dupa metoda indicata de 'qtype'.
%   INPUT:
%     a     = numarul ce trebuie cuantizat;
%     qtype = tipul de cuantizare:  't' = trunchiere
%                                   'r' = rotunjire,
%                                   'm' = trunchiere semn-marime;
%     B     = numarul de biti.
%   OUTPUT:
%     aq = valoarea rezultata in urma cuantizarii
% Metoda: Se scaleaza a cu 2**(B), se cuantizeaza la intreg, apoi se
% rescaleaza 
% *********************************************************

% s=scale2(a);
% scn=2^(B)/s;
% aq=a*2^(B)/s;

scn=2^(B);
aq=a*2^(B);

if (qtype=='t'),
   aq=1/scn*floor(aq);
elseif (qtype=='r'),
   aq=1/scn*round(aq);
elseif (qtype=='m'),
   aq=1/scn*(sign(aq).*floor(abs(aq)));
else
   error('Unrecognized ''qtype'' paramater; please specify ''t'', ''r'', or ''m''')
end

