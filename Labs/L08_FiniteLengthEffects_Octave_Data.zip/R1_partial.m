% R1

clear all
close all

% Parametri:
rp = ;        % Passband ripple
rs = ;        % Stopband ripple
fs = ;        % Sampling frequency
f =  ;        % Cutoff frequencies
a =  ;        % Desired amplitudes

% Calculul deviatie delta din riplul dorit r
dev = [10^(rp/20)-1  10^(-rs/20)]; 

% Estimarea ordinului necesar
[n,fo,ao,w] = firpmord( ... );

% Proiectarea filtrului
b = firpm( .... );

% Afisarea raspunsului in magnitudine si faza
freqz( ... );

% Cuantizare prin trunchiere, B = 12 biti
B = 12;
b_t12 = 
figure
freqz( ... );

% Cuantizare semn-valoare, B = 12 biti
B = 12;
b_m12 =
figure
freqz( ... );

% Cuantizare prin trunchiere, B = 6 biti
B = 6;
b_t6 = 
figure
freqz( ... );

% Cuantizare semn-valoare, B = 6 biti
B = 6;
b_m6 = 
figure
freqz( ... );

