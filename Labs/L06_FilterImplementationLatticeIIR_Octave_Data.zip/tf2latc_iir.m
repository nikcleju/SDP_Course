function [K, V] = tf2latc_iir(c, a)
  
  # Exemplu:
  # a = [1   2/5    7/20    1/2]
  # c = [1    2      3       2]
  
order = length(a) - 1;

K(order) = a(order+1);
b = fliplr(a);

V(order) = c(order+1);

for i=1:(order-1)
  # A_(m-1) based on previous A_m and B_m
  Km = K(order+1-i);
  Vm = V(order+1-i);
  
  # Compute new A_m-1 and C_m-1 based on A_m, B_m and C_m
  a = (a - Km * b) / (1 - Km^2);
  c = c - Vm * b;
  
  # Read new coeffs Km and Vm
  K(order+1-i-1) = a(order+1-i);
  V(order+1-i-1) = c(order+1-i);
  
  # Update b for new iteration
  a = a(1:order+1-i)
  b = fliplr(a);  
  c = c(1:order+1-i)
endfor

# One more step for C_0(z)
C0 = c  - V(1)*b;
V0 = C0(1);
V = [V0 V];
  

% Matlab: end
endfunction
